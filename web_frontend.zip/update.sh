
git stash
git pull
sudo rm -rf /var/www/html/*
sudo mv * /var/www/html/